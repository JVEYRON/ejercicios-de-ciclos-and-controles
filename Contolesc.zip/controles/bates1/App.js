import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  const styles = StyleSheet.create({
  contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
  },

    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
     },
    });
  let [resultado, setResultado] = useState('');
  let[precio, setPrecio] = useState('100');
  let [cantidad, setCantiddad] = useState('');
  

 const bates = () => {
   
   if (cantidad >= 10) {
                let total = cantidad * precio;
          const resultado = total;
          setResultado(resultado+" con descuento aplicado por mayoria");
        }
         if (cantidad < 10) {
          precio = 108;
                let total = cantidad * precio;
          let resultado = total;
          setResultado(resultado+" 'sin descuento por compra minoritaria.'");
         } 

    }
  return (
<View style={styles.contenedorButton}>
<TextInput
            placeholder="Unidades Compradas"
            value={cantidad}
            onChangeText={setCantiddad}
            keyboardType="numeric"
            
          />
    <Text> Total de compra por bates</Text>
                <View style={styles.contenedorA}>
                <Button title="Tester"  onPress={bates}/>
                </View>
                <Text>usted gasto: [ {resultado} ]</Text>
                  
   </View>

  );


}