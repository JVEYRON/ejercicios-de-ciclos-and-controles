import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  const styles = StyleSheet.create({
  contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
  },

    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
     },
    });
  let [resultado, setResultado] = useState('');
  let[precio, setPrecio] = useState('1.20');
  let [cantidad, setCantiddad] = useState('');
  

 const balones = () => {
   
   if (cantidad < 100 & cantidad > 50) {
                let total = cantidad * precio;
          const resultado = total;
          setResultado(resultado+" con descuento aplicado por mayoria");
        }
         if (cantidad >=30 & cantidad <=50) {
          precio = 1.50;
                let total = cantidad * precio;
          let resultado = total;
          setResultado(resultado+" 'mediana compra.'");
         } 

         if(cantidad < 30 ){
          precio = 2.10;
                let total = cantidad * precio;
          let resultado = total;
          setResultado(resultado+" 'minima compra.'");
         }

    }
  return (
<View style={styles.contenedorButton}>
<TextInput
            placeholder="Unidades Compradas"
            value={cantidad}
            onChangeText={setCantiddad}
            keyboardType="numeric"
            
          />
    <Text> Total de compra por Lapices</Text>
                <View style={styles.contenedorA}>
                <Button title="Tester"  onPress={balones}/>
                </View>
                <Text>usted gasto: [ {resultado} ]</Text>
                  
   </View>

  );


}