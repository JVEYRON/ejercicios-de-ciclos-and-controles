import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let diezEnDiez = () => {
    resultado = '';
    for (let i = 10; i <= 100; i += 10) {
      resultado += i + ' ';
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Números del 0 al 100 de diez en diez</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={diezEnDiez} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
