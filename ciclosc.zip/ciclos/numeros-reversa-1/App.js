
import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [num, setNum] = useState('');
  let [resultado, setResultado] = useState('');

  let mostrar = () => {
    let n = parseInt(num);
    let resultado = '';
    for (let i = 0; i < n; i++) {
      resultado += i + ' ';
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <TextInput
        placeholder="Número"
        value={num}
        onChangeText={setNum}
        keyboardType="numeric"
      />
      <Text>Números antes del ingresado</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={mostrar} />
      </View>
      <Text>[ {resultado} ]</Text>
    </View>
  );
}

