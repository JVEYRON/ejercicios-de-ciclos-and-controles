import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let calificaciones = () => {
    resultado = '';
    let cont = 0;

    while (cont < 10) {
      let cal = Math.floor(Math.random() * 11); // genera calificación entre 0 y 10
      if (cal >= 6 && cal <= 10) {
        resultado += cal + ' ';
        cont++;
      }
    }

    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Calificaciones válidas (6 a 10)</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={calificaciones} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
