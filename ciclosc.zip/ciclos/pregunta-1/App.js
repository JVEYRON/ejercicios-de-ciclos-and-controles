import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [respuesta, setRespuesta] = useState('');
  let [resultado, setResultado] = useState('');

  let continuar = () => {
    resultado = '';
    while (respuesta !== 'N') {
      resultado += '¿Desea continuar S/N? ';
      break; // simulación del ciclo hasta que ponga N
    }
    if (respuesta === 'N') {
      resultado = 'Programa terminado';
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>¿Desea continuar S/N?</Text>
      <TextInput
        placeholder="Escriba N para salir"
        value={respuesta}
        onChangeText={setRespuesta}
      />
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={continuar} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
