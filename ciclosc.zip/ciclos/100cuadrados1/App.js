import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let cuadrados = () => {
    let suma = 0;
    for (let i = 1; i <= 100; i++) {
      suma += i * i;
    }
    resultado = 'La suma de los cuadrados es: ' + suma;
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Suma de los cuadrados del 1 al 100</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={cuadrados} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
