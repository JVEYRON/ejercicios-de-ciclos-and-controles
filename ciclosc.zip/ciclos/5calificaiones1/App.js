import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let calificaciones = () => {
    resultado = ''; // reinicia el texto antes de comenzar
    for (let i = 1; i <= 5; i++) {
      resultado += 'Alumno ' + i + ': ';
      for (let j = 1; j <= 3; j++) {
        let cal = Math.floor(Math.random() * 11);
        resultado += cal + ' ';
      }
      resultado += '\n';
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>calificaciones</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={calificaciones} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
