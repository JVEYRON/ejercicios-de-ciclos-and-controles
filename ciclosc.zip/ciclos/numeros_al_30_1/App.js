import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let mostrar = () => {
    let resultado = '';
    for (let i = 1; i <= 30; i++) {
      resultado += i + ' ';
      if (i % 7 == 0) {
        resultado += '\n';
      }
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Números del 1 al 30 con salto cada 7</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={mostrar} />
      </View>
      <Text>[ {resultado} ]</Text>
    </View>
  );
}
