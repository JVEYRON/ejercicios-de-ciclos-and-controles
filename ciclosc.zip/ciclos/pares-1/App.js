import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [resultado, setResultado] = useState('');

  let pares = () => {
    resultado = '';
    for (let i = 2; i <= 15; i++) {
      if (i % 2 === 0) {
        resultado += i + ' ';
      }
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Números pares del 2 al 15</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={pares} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
