import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [cal, setCal] = useState('');
  let [resultado, setResultado] = useState('');

  let verificar = () => {
    let c = parseFloat(cal);
    if (c >= 0 && c <= 10) {
      setResultado('Calificación válida: ' + c);
    } else {
      setResultado('Calificación inválida, intenta de nuevo');
    }
  };

  return (
    <View style={styles.contenedorButton}>
      <TextInput
        placeholder="Calificación"
        value={cal}
        onChangeText={setCal}
        keyboardType="numeric"
      />
      <Text>Verificar calificación</Text>
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={verificar} />
      </View>
      <Text>[ {resultado} ]</Text>
    </View>
  );
}
