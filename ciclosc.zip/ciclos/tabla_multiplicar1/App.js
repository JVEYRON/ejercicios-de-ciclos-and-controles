import { StatusBar } from 'expo-status-bar';
import { View, Text, TextInput, StyleSheet, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  let styles = StyleSheet.create({
    contenedorButton: {
      flex: 1,
      backgroundColor: '#ffffffff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    contenedorA: {
      marginTop: 12,
      marginBottom: 10,
    },
  });

  let [num, setNum] = useState('');
  let [resultado, setResultado] = useState('');

  let tabla = () => {
    let n = parseInt(num);
    resultado = '';
    for (let i = 1; i <= 10; i++) {
      resultado += n + ' x ' + i + ' = ' + (n * i) + '\n';
    }
    setResultado(resultado);
  };

  return (
    <View style={styles.contenedorButton}>
      <Text>Tabla de multiplicar</Text>
      <TextInput
        placeholder="Número"
        value={num}
        onChangeText={setNum}
        keyboardType="numeric"
      />
      <View style={styles.contenedorA}>
        <Button title="Test" onPress={tabla} />
      </View>
      <Text>{resultado}</Text>
    </View>
  );
}
